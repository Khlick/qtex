"""Quick Python Tex/Latex Integrator (qpytexi)"""

__version__ = "0.1.5" 