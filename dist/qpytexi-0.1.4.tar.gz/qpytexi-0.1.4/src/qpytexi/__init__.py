"""QuickPyTexIntegrator - A LaTeX exam compiler utility."""

__version__ = "0.1.4" 