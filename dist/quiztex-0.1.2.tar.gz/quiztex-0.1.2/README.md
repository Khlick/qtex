# QuizTeX

A command-line utility for rendering qtex files and compiling LaTeX exam files. QuizTeX provides two main commands:
- `render`: Process qtex files into LaTeX documents with support for Python code execution
- `compile`: Compile LaTeX files in a directory or from a CSV list


## Installation

```bash
# Render qtex files
qtex render -exam-json exam.json -student-csv students.csv
qtex render --source ./source --output ./output --shuffle

# Compile LaTeX files
qtex compile directory_path
qtex compile students.csv --source /path/to/source --key studentname
```
